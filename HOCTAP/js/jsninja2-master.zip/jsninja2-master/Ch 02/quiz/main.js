const question = "What is Superman's real name?"
const answer = prompt(question);
alert(`You answered ${answer}`);
