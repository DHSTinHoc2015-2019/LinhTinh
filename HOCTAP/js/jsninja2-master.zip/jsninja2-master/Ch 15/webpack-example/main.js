import _ from 'lodash';
console.log(_.now());
