alert('Welcome to Quiz Ninja!');
